package com.example.housingsociety.fragments;


import android.app.ProgressDialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.housingsociety.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

/**
 * A simple {@link Fragment} subclass.
 */
public class LoginFragment extends Fragment {

    private Button btnSubmit;
    private TextInputLayout layoutUserName, layoutPassword;
    private EditText etUserName, etPassword;
    private FirebaseAuth mAuth;
    ProgressDialog pd;
    public LoginFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_login, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mAuth=FirebaseAuth.getInstance();
        layoutUserName=view.findViewById(R.id.layoutUserName);
        layoutPassword=view.findViewById(R.id.layoutPassword);
        etUserName=view.findViewById(R.id.etUserName);
        etPassword=view.findViewById(R.id.etPassword);

        btnSubmit=view.findViewById(R.id.btnSubmit);



        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String userName=etUserName.getText().toString();
                if(userName.isEmpty()){
                    layoutUserName.setError(getString(R.string.required));
                    return;
                }
                String password=etPassword.getText().toString();
                if(password.isEmpty()){
                    layoutPassword.setError(getString(R.string.required));
                    return;
                }
                if(password.length()<6){
                    layoutPassword.setError(getString(R.string.minimum_6_error));
                    return;
                }
                /*Fragment fragment=new MainFragment();
               getFragmentManager()
                        .beginTransaction()
                       .replace(R.id.frame,fragment)
                        .commit();*/
                signinWithEmailAndPassword(userName,password);
            }
        });
    }

    private void signinWithEmailAndPassword(String userName, String password) {
        pd=ProgressDialog.show(getContext(),"Wait","Authenticating....");
        mAuth.signInWithEmailAndPassword(userName,password)
                .addOnCompleteListener(getActivity(), new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        pd.dismiss();
                        if(task.isSuccessful()){
                            FirebaseUser currentUser=mAuth.getCurrentUser();
                            updateUI(currentUser);
                        }else{
                            Toast.makeText(getContext(), "Email or Password is Wrong", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }


    @Override
    public void onStart() {
        super.onStart();
        FirebaseUser currentUser=mAuth.getCurrentUser();
        updateUI(currentUser);
    }

    private void updateUI(FirebaseUser currentUser) {
        if(currentUser!=null){
                Fragment fragment=new MainFragment();
                getFragmentManager()
                        .beginTransaction()
                        .replace(R.id.frame,fragment)
                        .commit();
        }
    }
}
