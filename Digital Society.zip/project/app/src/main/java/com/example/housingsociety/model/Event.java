package com.example.housingsociety.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Event implements Parcelable {
    private String eventName, eventDetails, eventDate;

    public Event(String eventName,String eventDetails,String eventDate)
    {
        this.eventName=eventName;
        this.eventDetails=eventDetails;
        this.eventDate=eventDate;
    }


    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventDetails() {
        return eventDetails;
    }

    public void setEventDetails(String eventDetails) {
        this.eventDetails = eventDetails;
    }

    public String getEventDate() {
        return eventDate;
    }

    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {

    }
}
