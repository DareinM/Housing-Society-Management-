package com.example.housingsociety.fragments;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.housingsociety.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class MaintenanceListFragment extends Fragment {


    public MaintenanceListFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_maintenance_list, container, false);
    }

}
