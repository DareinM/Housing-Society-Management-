package com.example.housingsociety.model;

public class Vehical {
    private String userId, vehicleNo, vehicleType;

    public Vehical(String userId, String vehicleNo, String vehicleType){
        this.userId=userId;
        this.vehicleNo=vehicleNo;
        this.vehicleType=vehicleType;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getVehicleNo() {
        return vehicleNo;
    }

    public void setVehicleNo(String vehicleNo) {
        this.vehicleNo = vehicleNo;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }
}
