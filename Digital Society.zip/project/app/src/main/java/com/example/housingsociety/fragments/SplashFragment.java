package com.example.housingsociety.fragments;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.housingsociety.R;
import com.example.housingsociety.activities.MainActivity;

/**
 * A simple {@link Fragment} subclass.
 */
public class SplashFragment extends Fragment {

    public static int DURATION=3000;
    private Context context;
    public SplashFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_splash, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        context=getContext();

        Handler handler=new Handler();
        // Anonymous implementation of Runnable
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // jump from one activity to another
                Intent intent=new Intent(context, MainActivity.class);
                startActivity(intent);
                //finish();
            }
        },DURATION);
    }
}
