package com.example.housingsociety.model;

public class Complaint {
    private String userId, complain, date, status;

    public Complaint(){

    }


    public Complaint(String userId, String complain) {
        this.userId = userId;
        this.complain = complain;
        //this.date = date;
        //this.status = status;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getComplain() {
        return complain;
    }

    public void setComplain(String complain) {
        this.complain = complain;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
