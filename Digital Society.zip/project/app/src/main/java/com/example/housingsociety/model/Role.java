package com.example.housingsociety.model;

public class Role {
    private String admin, societyMembers, secratory, security;

    public Role(String admin, String societyMembers,String secratory, String security){
        this.admin=admin;
        this.societyMembers=societyMembers;
        this.secratory=secratory;
        this.security=security;
    }

    public String getAdmin() {
        return admin;
    }

    public void setAdmin(String admin) {
        this.admin = admin;
    }

    public String getSocietyMembers() {
        return societyMembers;
    }

    public void setSocietyMembers(String societyMembers) {
        this.societyMembers = societyMembers;
    }

    public String getSecratory() {
        return secratory;
    }

    public void setSecratory(String secratory) {
        this.secratory = secratory;
    }

    public String getSecurity() {
        return security;
    }

    public void setSecurity(String security) {
        this.security = security;
    }
}
