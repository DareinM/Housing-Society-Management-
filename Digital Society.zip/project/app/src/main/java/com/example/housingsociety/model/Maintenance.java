package com.example.housingsociety.model;

public class Maintenance {
    private String userId, maintenance, month, remark;

    public Maintenance(String userId, String maintenance,String month,String remark){
        this.userId=userId;
        this.maintenance=maintenance;
        this.month=month;
        this.remark=remark;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getMaintenance() {
        return maintenance;
    }

    public void setMaintenance(String maintenance) {
        this.maintenance = maintenance;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
