package com.example.housingsociety.adapters;

public class VehicalAdapter {
}
