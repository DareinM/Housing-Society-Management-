package com.example.housingsociety.other;

public interface Constants {
    String MEMBERS = "members";
    String COMPLAIN= "complain";
    String GALLERY="gallery";
    String EVENT="event";
    String IMAGES = "images";
}
