package com.example.housingsociety.model;

public class Profession {
    private String userId, professionName;

    public Profession(String userId,String professionName){
        this.userId=userId;
        this.professionName=professionName;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getProfessionName() {
        return professionName;
    }

    public void setProfessionName(String professionName) {
        this.professionName = professionName;
    }
}
