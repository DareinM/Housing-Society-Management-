package com.example.housingsociety.fragments;


import android.app.ProgressDialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.housingsociety.R;
import com.example.housingsociety.adapters.MemberAdapter;
import com.example.housingsociety.model.Member;
import com.example.housingsociety.other.Constants;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * A simple {@link Fragment} subclass.
 */
public class MemberListFragment extends Fragment implements MemberAdapter.MemberClickListener {

    private ProgressDialog pd;

    private RecyclerView recyclerView;
    //private ArrayList<Member> memberList;
    private ArrayList<HashMap<String, Member>> memberList;
    public MemberListFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Member List");
        return inflater.inflate(R.layout.fragment_member_list, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // this fragment has option menu
        setHasOptionsMenu(true);

        recyclerView=view.findViewById(R.id.recyclerView);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        //prepareData();
        readMemberData();
    }

    private void readMemberData() {
        final FirebaseDatabase database=FirebaseDatabase.getInstance();
        DatabaseReference reference=database.getReference(Constants.MEMBERS);
        reference.addValueEventListener(new ValueEventListener() {


            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                memberList=new ArrayList<>();
                for(DataSnapshot ds : dataSnapshot.getChildren()){
                    String key=ds.getKey();
                    Member member=ds.getValue(Member.class);
                    HashMap<String, Member> hashMap=new HashMap<>();
                    hashMap.put(key, member);

                    memberList.add(hashMap);
                }
                setAdapter();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getContext(), databaseError.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setAdapter() {
        MemberAdapter adapter=new MemberAdapter(memberList,this);
        recyclerView.setAdapter(adapter);
    }

//    private void prepareData() {
        //memberList=new ArrayList<>();
//        memberList.add(new Member("1", "ABC", "ABC", "101", "5", "Yes", "1", "123123123", "7878989855", "abc@gmail.com", "Abc@123"));
//        memberList.add(new Member("1", "ABC", "ABC", "101", "5", "Yes", "1", "123123123", "7878989855", "abc@gmail.com", "Abc@123"));
//        memberList.add(new Member("1", "ABC", "ABC", "101", "5", "Yes", "1", "123123123", "7878989855", "abc@gmail.com", "Abc@123"));
//        memberList.add(new Member("1", "ABC", "ABC", "101", "5", "Yes", "1", "123123123", "7878989855", "abc@gmail.com", "Abc@123"));
//        memberList.add(new Member("1", "ABC", "ABC", "101", "5", "Yes", "1", "123123123", "7878989855", "abc@gmail.com", "Abc@123"));

     //   MemberAdapter adapter=new MemberAdapter(memberList);
    //  recyclerView.setAdapter(adapter);
//}

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.new_member_menu,menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.action_new){
            Fragment fragment=new NewMemberFragment();
            getFragmentManager()
                    .beginTransaction()
                    .replace(R.id.frame,fragment)
                    .addToBackStack(MemberListFragment.class.getName())
                    .commit();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onMemberEdit(String key, Member member) {
        Bundle bundle=new Bundle();
        bundle.putString("key",key);
        bundle.putParcelable("member",member);

        Fragment fragment=new NewMemberFragment();
        fragment.setArguments(bundle);

        getFragmentManager()
                .beginTransaction()
                .replace(R.id.frame,fragment)
                .addToBackStack(MemberListFragment.class.getName())
                .commit();
    }

    @Override
    public void onMemberDelete(String key, Member member) {
        pd= ProgressDialog.show(getContext(),"Wait..,","Removing Data...");
        FirebaseDatabase database=FirebaseDatabase.getInstance();
        DatabaseReference reference=database.getReference(Constants.MEMBERS).child(key);
        reference.removeValue() .addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                pd.dismiss();
                if(task.isSuccessful()){
                    Toast.makeText(getContext(), "Removed Successfully...", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getContext(), "Operation Fail...", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}
