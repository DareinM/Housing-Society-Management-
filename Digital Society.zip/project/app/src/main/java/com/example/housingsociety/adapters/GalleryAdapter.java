package com.example.housingsociety.adapters;

import android.content.Context;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.housingsociety.R;
import com.example.housingsociety.model.Gallery;
import com.example.housingsociety.other.Constants;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.HashMap;

public class GalleryAdapter extends RecyclerView.Adapter<GalleryAdapter.GalleryViewHolder> {

    private ArrayList<HashMap<String, String>> galleryList;
    private Context context;
    public interface OnImageDeleteListener{
        void onImageDelete(String key, String image);
    }
    OnImageDeleteListener listener;
    public GalleryAdapter(ArrayList<HashMap<String,String>> galleryList, OnImageDeleteListener listener) {
        this.galleryList=galleryList;
        this.listener=listener;
    }

    @NonNull
    @Override
    public GalleryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context=parent.getContext();
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.gallery_row_item,parent,false);
        GalleryViewHolder holder=new GalleryViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull GalleryAdapter.GalleryViewHolder holder, int position) {
        HashMap<String,String> hashMap=galleryList.get(position);
        final String key=hashMap.keySet().iterator().next();
        final String image=hashMap.get(key);
        FirebaseStorage mStorage= FirebaseStorage.getInstance();
        StorageReference mStorageRef = mStorage.getReference(Constants.IMAGES+"/" + image);
        Glide.with(context /* context */)
                .load(mStorageRef)
                .into(holder.imageView);
        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onImageDelete(key, image);
            }
        });
    }

    @Override
    public int getItemCount() {
        return galleryList.size();
    }

    public class GalleryViewHolder extends RecyclerView.ViewHolder {
        ImageButton btnDelete;
        ImageView imageView;
        public GalleryViewHolder(@NonNull View itemView) {
            super(itemView);
            btnDelete=itemView.findViewById(R.id.btnDelete);
            imageView=itemView.findViewById(R.id.imageView);
        }
    }
}
