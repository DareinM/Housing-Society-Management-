package com.example.housingsociety.model;

public class Fund {
    private String userId, amount, details, date;

    public Fund(String userId,String amount,String details,String date){
        this.userId=userId;
        this.amount=amount;
        this.details=details;
        this.date=date;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
