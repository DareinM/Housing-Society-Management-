package com.example.housingsociety.model;

public class Gallery {
    private String image, remarks;

    public Gallery(String image, String remarks){
        this.image=image;
        this.remarks=remarks;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
