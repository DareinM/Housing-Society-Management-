package com.example.housingsociety.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Member implements Parcelable {
    private String userId;
    private String firstName;
    private String lastName;
    private String houseNo;
    private String noOfPerson;
    private String isOwner;
    private String professionId;
    private String aadharNo;
    private String contactNo;
    private String email;
    private String passsword;

    public Member(){

    }

    public Member(String firstName, String lastName, String houseNo, String noOfPerson, String isOwner, String professionId, String aadharNo, String contactNo, String email) {
        //this.userId = userId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.houseNo = houseNo;
        this.noOfPerson = noOfPerson;
        this.isOwner = isOwner;
        this.professionId = professionId;
        this.aadharNo = aadharNo;
        this.contactNo = contactNo;
        this.email = email;
        //this.passsword = passsword;
    }

    protected Member(Parcel in) {
        userId = in.readString();
        firstName = in.readString();
        lastName = in.readString();
        houseNo = in.readString();
        noOfPerson = in.readString();
        isOwner = in.readString();
        professionId = in.readString();
        aadharNo = in.readString();
        contactNo = in.readString();
        email = in.readString();
        passsword = in.readString();
    }

    public static final Creator<Member> CREATOR = new Creator<Member>() {
        @Override
        public Member createFromParcel(Parcel in) {
            return new Member(in);
        }

        @Override
        public Member[] newArray(int size) {
            return new Member[size];
        }
    };

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getHouseNo() {
        return houseNo;
    }

    public void setHouseNo(String houseNo) {
        this.houseNo = houseNo;
    }

    public String getNoOfPerson() {
        return noOfPerson;
    }

    public void setNoOfPerson(String noOfPerson) {
        this.noOfPerson = noOfPerson;
    }

    public String getIsOwner() {
        return isOwner;
    }

    public void setIsOwner(String isOwner) {
        this.isOwner = isOwner;
    }

    public String getProfessionId() {
        return professionId;
    }

    public void setProfessionId(String professionId) {
        this.professionId = professionId;
    }

    public String getAadharNo() {
        return aadharNo;
    }

    public void setAadharNo(String aadharNo) {
        this.aadharNo = aadharNo;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPasssword() {
        return passsword;
    }

    public void setPasssword(String passsword) {
        this.passsword = passsword;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(userId);
        dest.writeString(firstName);
        dest.writeString(lastName);
        dest.writeString(houseNo);
        dest.writeString(noOfPerson);
        dest.writeString(isOwner);
        dest.writeString(professionId);
        dest.writeString(aadharNo);
        dest.writeString(contactNo);
        dest.writeString(email);
        dest.writeString(passsword);
    }
}
