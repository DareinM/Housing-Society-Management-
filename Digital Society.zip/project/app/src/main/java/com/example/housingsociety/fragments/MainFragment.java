package com.example.housingsociety.fragments;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;

import com.example.housingsociety.R;
import com.google.firebase.auth.FirebaseAuth;

/**
 * A simple {@link Fragment} subclass.
 */
public class MainFragment extends Fragment {

    private GridView gridView;

    public MainFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        setHasOptionsMenu(true);
        return inflater.inflate(R.layout.fragment_main, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        gridView=view.findViewById(R.id.gridView);
        final Fragment[] fragments={
            new MemberListFragment(),
            new GalleryViewFragment(),
                new EventViewFragment(),
            new MaintenanceFragment(),
            new ComplainViewFragment(),
                new ComplainViewFragment()
        };
        String[] items=getResources().getStringArray(R.array.items);
        //ArrayAdapter<String> adapter=new ArrayAdapter<>(getContext(),android.R.layout.simple_list_item_1,items);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(getContext(),R.layout.grid_row_item,R.id.tvTitle,items);
        gridView.setAdapter(adapter);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Fragment fragment=fragments[position];
                getFragmentManager()
                        .beginTransaction()
                        .replace(R.id.frame,fragment)
                        .addToBackStack(MainFragment.class.getName())
                        .commit();
            }
        });
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.main_menu,menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.action_logout){
            FirebaseAuth mAuth=FirebaseAuth.getInstance();
            mAuth.signOut();
            getActivity().finish();
        }
        return super.onOptionsItemSelected(item);

    }
}
