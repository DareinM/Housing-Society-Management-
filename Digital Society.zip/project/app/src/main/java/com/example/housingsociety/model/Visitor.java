package com.example.housingsociety.model;

public class Visitor {
    private String firstName;
    private String lastName;
    private String houseNo;
    private String contactNo;
    private String date;
    private String time;

    public Visitor(String firstName,String lastName, String houseNo,String contactNo, String date, String time){
        this.firstName=firstName;
        this.lastName=lastName;
        this.houseNo=houseNo;
        this.contactNo=contactNo;
        this.date=date;
        this.time=time;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getHouseNo() {
        return houseNo;
    }

    public void setHouseNo(String houseNo) {
        this.houseNo = houseNo;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
