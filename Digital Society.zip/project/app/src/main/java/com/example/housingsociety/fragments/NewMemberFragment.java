package com.example.housingsociety.fragments;


import android.app.ProgressDialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.housingsociety.R;
import com.example.housingsociety.model.Member;
import com.example.housingsociety.other.Constants;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.security.acl.Owner;

/**
 * A simple {@link Fragment} subclass.
 */
public class NewMemberFragment extends Fragment {

    String key=null;
   private Button btnNext;
   private ProgressDialog pd;
   private TextInputLayout layoutFirstName,layoutLastName,layoutHouseNo,layoutPerson,layoutProfession,layoutAadharNumber,layoutContact,layoutEMail;
   private EditText etFirstName, etLastName,etHouseNo,etPerson,etProfession,etAadharNumber,etContact,etEMail;
   private RadioGroup radioGender,radioOwnership;
   private RadioButton rbOwner, rbPG;
   // owner = 1, pg= 0
   String owner ="";
   // Male = 1, Female = 0  /-1
   String gender ="";

    public NewMemberFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("New Member");
        return inflater.inflate(R.layout.fragment_new_member, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        layoutFirstName=view.findViewById(R.id.layoutFirstName);
        layoutLastName=view.findViewById(R.id.layoutLastName);
        layoutHouseNo=view.findViewById(R.id.layoutHouseNo);
        layoutPerson=view.findViewById(R.id.layoutPerson);
        layoutProfession=view.findViewById(R.id.layoutProfession);
        layoutAadharNumber=view.findViewById(R.id.layoutAadharNumber);
        layoutContact=view.findViewById(R.id.layoutContact);
        layoutEMail=view.findViewById(R.id.layoutEMail);
        etFirstName=view.findViewById(R.id.etFirstName);
        etLastName=view.findViewById(R.id.etLastName);
        etHouseNo=view.findViewById(R.id.etHouseNo);
        etPerson=view.findViewById(R.id.etPerson);
        etProfession=view.findViewById(R.id.etProfession);
        etAadharNumber=view.findViewById(R.id.etAadharNumber);
        etContact=view.findViewById(R.id.etContact);
        etEMail=view.findViewById(R.id.etEMail);
        radioGender=view.findViewById(R.id.radioGender);
        radioOwnership=view.findViewById(R.id.radioOwnership);
        rbOwner=view.findViewById(R.id.radioOwner);
        rbPG=view.findViewById(R.id.radioPG);
        btnNext=view.findViewById(R.id.btnNext);

        Bundle bundle=getArguments();
        if(bundle!=null) {
            key = bundle.getString("key");
            Member member = bundle.getParcelable("member");
            if (member != null) {
                etFirstName.setText(member.getFirstName());
                etLastName.setText(member.getLastName());
                etHouseNo.setText(member.getHouseNo());
                etAadharNumber.setText(member.getAadharNo());
                etContact.setText(member.getContactNo());
                etEMail.setText(member.getEmail());
                etPerson.setText(member.getNoOfPerson());
                etProfession.setText(member.getProfessionId());
                String isOwner=member.getIsOwner();
                if(isOwner.equals("Yes")){
                    rbOwner.setChecked(true);
                }else{
                    rbPG.setChecked(true);
                }

            }
        }

        radioGender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {


                      /*  if (group.getCheckedRadioButtonId()){
                            Toast.makeText(getContext(),"Select Gender",Toast.LENGTH_SHORT).show();
                        }*/


                switch (checkedId){
                    case R.id.radioMale:
                        Toast.makeText(getActivity(), "Male", Toast.LENGTH_SHORT).show();
                        gender ="Male";
                        break;
                    case R.id.radioFemale:
                        Toast.makeText(getActivity(), "Female", Toast.LENGTH_SHORT).show();
                        gender = "Female";
                        break;
                }

            }
        });


        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isValid=true;
                String FirstName=etFirstName.getText().toString();
                if (FirstName.isEmpty()){
                    layoutFirstName.setError("Required");
                    isValid=false;
                   // return;
                }
                String LastName=etLastName.getText().toString();
                if (LastName.isEmpty()){
                    layoutLastName.setError("Required");
                    isValid=false;
                    //return;
                }
                String HouseNo=etHouseNo.getText().toString();
                if (HouseNo.isEmpty()){
                    layoutHouseNo.setError("Required");
                    isValid=false;
                    //return;
                }
                String Person=etPerson.getText().toString();
                if (Person.isEmpty()){
                    layoutPerson.setError("Required");
                    isValid=false;
                    //return;
                }
                if(radioGender.getCheckedRadioButtonId()==-1){
                    Toast.makeText(getContext(), "Please Select Gender...", Toast.LENGTH_SHORT).show();
                    isValid=false;
                    //return;
                }

                if(radioOwnership.getCheckedRadioButtonId()==-1){
                    Toast.makeText(getContext(), "Please Select Owner...", Toast.LENGTH_SHORT).show();
                    isValid=false;
                    //return;
                }else{
                    if(rbOwner.isChecked()){
                        owner="Yes";
                    }else{
                        owner="No";
                    }
                }
                String Profession=etProfession.getText().toString();
                if (Profession.isEmpty()){
                    layoutProfession.setError("Required");
                    isValid=false;
                    //return;
                }
                String AadharNumber=etAadharNumber.getText().toString();
                if (AadharNumber.isEmpty()){
                    layoutAadharNumber.setError("Required");
                    isValid=false;
                    //return;
                }
                String Contact=etContact.getText().toString();
                if (Contact.isEmpty()){
                    layoutContact.setError("Required");
                    isValid=false;
                    //return;
                }
                String EMail=etEMail.getText().toString();
                if (EMail.isEmpty()){
                    layoutEMail.setError("Required");
                    isValid=false;
                    //return;
                }

                if(isValid){
                    // submit Form
                    Member member=new Member(FirstName,LastName,HouseNo,Person,owner,Profession,AadharNumber,Contact,EMail);
                    submitMemberDetails(member);
                }


            }
        });



        radioOwnership.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch (checkedId){
                    case R.id.radioOwner:
                        owner="Yes";
                        break;
                    case R.id.radioPG:
                        owner="No";
                        break;
                }
            }
        });



    }

    private void submitMemberDetails(Member member) {
        pd=ProgressDialog.show(getContext(),"Wait..,","Saving Data...");
        FirebaseDatabase database=FirebaseDatabase.getInstance();

        DatabaseReference reference=database.getReference(Constants.MEMBERS);
        if(key==null){
            reference=reference.push();
        }
        else{
            reference=reference.child(key);
        }
        reference.setValue(member)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        pd.dismiss();
                        if(task.isSuccessful()){
                            Toast.makeText(getContext(), "Saved Successfully...", Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(getContext(), "Operation Fail...", Toast.LENGTH_SHORT).show();
                        }
                        getFragmentManager().popBackStack();
                    }
                });
    }
}
