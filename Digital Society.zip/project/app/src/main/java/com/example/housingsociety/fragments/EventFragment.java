package com.example.housingsociety.fragments;


import android.app.ProgressDialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.housingsociety.R;
import com.example.housingsociety.model.Event;
import com.example.housingsociety.other.Constants;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * A simple {@link Fragment} subclass.
 */
public class EventFragment extends Fragment {

    String key=null;
    private ProgressDialog pd;
    private Button btnESubmit;
    private TextInputLayout layoutEventName,layoutEventDetails,layoutEventDate;
    private EditText etEventName,etEventDetails,etEventDate;


    public EventFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_event, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
         layoutEventName=view.findViewById(R.id.layoutEventName);
         layoutEventDetails=view.findViewById(R.id.layoutEventDetails);
         layoutEventDate=view.findViewById(R.id.layoutEventDate);

         etEventName=view.findViewById(R.id.etEventName);
         etEventDetails=view.findViewById(R.id.etEventDetails);
         etEventDate=view.findViewById(R.id.etEventDate);
         btnESubmit=view.findViewById(R.id.btnESubmit);

        Bundle bundle=getArguments();
        if(bundle!=null) {
            key = bundle.getString("key");
            Event event = bundle.getParcelable("event");
            if (event != null) {
                etEventDate.setText(event.getEventDate());
                etEventDetails.setText(event.getEventDetails());
                etEventName.setText(event.getEventName());

            }
        }
         btnESubmit.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 boolean isValid=true;
                 String EventName=etEventName.getText().toString();
                 if(EventName.isEmpty()){
                     layoutEventName.setError("Required");
                     isValid=false;
                 }
                 String EventDetails=etEventDetails.getText().toString();
                 if (EventDetails.isEmpty()){
                     layoutEventDetails.setError("Required");
                     isValid=false;
                 }

                 String EventDate=etEventDate.getText().toString();
                 if(EventDate.isEmpty()){
                     layoutEventDate.setError("Required");
                     isValid=false;
                 }

                 if(isValid){
                     Event event=new Event(EventName,EventDetails,EventDate);
                     submitEventDetails(event);
                 }
             }
         });
    }

    private void submitEventDetails(Event event) {
        pd= ProgressDialog.show(getContext(),"Wait..,","Saving Data...");
        FirebaseDatabase database=FirebaseDatabase.getInstance();

        DatabaseReference reference=database.getReference(Constants.EVENT);
        if(key==null){
            reference=reference.push();
        }
        else{
            reference=reference.child(key);
        }
        reference.setValue(event)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        pd.dismiss();
                        if(task.isSuccessful()){
                            Toast.makeText(getContext(), "Saved Successfully...", Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(getContext(), "Operation Fail...", Toast.LENGTH_SHORT).show();
                        }
                        getFragmentManager().popBackStack();
                    }
                });
    }
}
