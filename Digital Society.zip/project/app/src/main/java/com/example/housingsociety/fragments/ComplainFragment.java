package com.example.housingsociety.fragments;


import android.app.ProgressDialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.housingsociety.R;
import com.example.housingsociety.model.Complaint;
import com.example.housingsociety.other.Constants;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * A simple {@link Fragment} subclass.
 */
public class ComplainFragment extends Fragment {

    private ProgressDialog pd;
    private EditText etComplainUID,etComplain;
    private Button btnComplain;


    public ComplainFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Complain");
        return inflater.inflate(R.layout.fragment_complain, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        etComplainUID=view.findViewById(R.id.etComplainUID);
        etComplain=view.findViewById(R.id.etComplain);
        btnComplain=view.findViewById(R.id.btnComplain);

        btnComplain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Boolean isValid=true;
                String ComplainUID=etComplainUID.getText().toString();
                if(ComplainUID.isEmpty()){
                    etComplainUID.setError("Required");
                    isValid=false;
                }
                String Complain=etComplain.getText().toString();
                if(Complain.isEmpty()){
                    etComplain.setError("Required");
                    isValid=false;
                }
                if(isValid){
                    Complaint complain= new Complaint(ComplainUID,Complain);
                    submitComplainDetails(complain);
                }
            }
        });

    }

    private void submitComplainDetails(Complaint complain) {
        pd=ProgressDialog.show(getContext(),"Wait...","Saving Data...");
        FirebaseDatabase database=FirebaseDatabase.getInstance();
        DatabaseReference reference=database.getReference(Constants.COMPLAIN).push();
        reference.setValue(complain)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        pd.dismiss();
                        if(task.isSuccessful()){
                            Toast.makeText(getContext(), "Saved Successfully...", Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(getContext(), "Operation Fail...", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}
