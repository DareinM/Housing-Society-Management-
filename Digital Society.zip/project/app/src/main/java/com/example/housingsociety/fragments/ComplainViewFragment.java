package com.example.housingsociety.fragments;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.housingsociety.R;
import com.example.housingsociety.adapters.ComplainAdapter;
import com.example.housingsociety.model.Complaint;
import com.example.housingsociety.other.Constants;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * A simple {@link Fragment} subclass.
 */
public class ComplainViewFragment extends Fragment {
    private RecyclerView recyclerView;
    private ArrayList<HashMap<String, Complaint>> complaintlist;


    public ComplainViewFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Complain List");
        return inflater.inflate(R.layout.fragment_complain_view, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setHasOptionsMenu(true);

        recyclerView=view.findViewById(R.id.recyclerView);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        readComplainData();
    }

    private void readComplainData() {
        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference reference = database.getReference(Constants.COMPLAIN);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                complaintlist = new ArrayList<>();
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    String key = ds.getKey();
                    Complaint complain = ds.getValue(Complaint.class);
                    HashMap<String, Complaint> hashMap = new HashMap<>();
                    hashMap.put(key, complain);

                    complaintlist.add(hashMap);
                }
                setAdapter();
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getContext(), databaseError.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

        private void setAdapter(){
            ComplainAdapter adapter=new ComplainAdapter(complaintlist);
            recyclerView.setAdapter(adapter);
        }



    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.new_member_menu,menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.action_new){
            Fragment fragment=new ComplainFragment();
            getFragmentManager()
                    .beginTransaction()
                    .replace(R.id.frame,fragment)
                    .addToBackStack(ComplainFragment.class.getName())
                    .commit();
        }
        return super.onOptionsItemSelected(item);
    }

}






