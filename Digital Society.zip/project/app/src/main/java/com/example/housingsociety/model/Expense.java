package com.example.housingsociety.model;

public class Expense {
    private String amount, description, date, billImage;


    public Expense(String amount,String description,String date,String billImage){
        this.amount=amount;
        this.description=description;
        this.date=date;
        this.billImage=billImage;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getBillImage() {
        return billImage;
    }

    public void setBillImage(String billImage) {
        this.billImage = billImage;
    }
}
