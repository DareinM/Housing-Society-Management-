package com.example.housingsociety.adapters;

public class VisitorAdapter {
}
