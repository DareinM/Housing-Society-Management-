package com.example.housingsociety.fragments;


import android.app.DatePickerDialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;

import com.example.housingsociety.R;
import com.google.android.material.textfield.TextInputLayout;

import java.util.Calendar;

/**
 * A simple {@link Fragment} subclass.
 */
public class MaintenanceFragment extends Fragment {
    private ImageView imageDatePicker;
    private Button btnSubmitMD;
    //private TextInputLayout layoutUID,layoutMaintenanceName,layoutMaintenanceDetails,layoutMaintenanceDate;
    private EditText etMaintenanceDetails,etUID,etMaintenanceName,etMaintenanceDate;
    public MaintenanceFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().setTitle("Maintenance");
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_maintenance, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        /*layoutUID=view.findViewById(R.id.layoutUID);
        layoutMaintenanceName=view.findViewById(R.id.layoutMaintenanceName);
        layoutMaintenanceDetails=view.findViewById(R.id.layoutMaintenanceDetails);
        layoutMaintenanceDate=view.findViewById(R.id.layoutMaintenanceDate);*/

        etUID=view.findViewById(R.id.etUID);
        etMaintenanceName=view.findViewById(R.id.etMaintenanceName);
        etMaintenanceDetails=view.findViewById(R.id.etMaintenanceDetails);
        etMaintenanceDate=view.findViewById(R.id.etMaintenanceDate);
        imageDatePicker=view.findViewById(R.id.imageDatePicker);
        btnSubmitMD=view.findViewById(R.id.btnSubmitMD);


        imageDatePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });

        btnSubmitMD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userID=etUID.getText().toString();
                if(userID.isEmpty()){
                    etUID.setError("Required");
                }
                String MainName=etMaintenanceName.getText().toString();
                if(MainName.isEmpty()){
                    etMaintenanceName.setError("Required");
                }
                String MainDetails=etMaintenanceDetails.getText().toString();
                if(MainDetails.isEmpty()){
                    etMaintenanceDetails.setError("Required");
                }
                String MainDate=etMaintenanceDate.getText().toString();
                if(MainDate.isEmpty()){
                    etMaintenanceDate.setError("Required");
                }

            }
        });
    }

    private void showDatePickerDialog() {
        Calendar calendar=Calendar.getInstance();
        int year=calendar.get(Calendar.YEAR);
        int month=calendar.get(Calendar.MONTH);
        int dayOfMonth=calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog=new DatePickerDialog(getContext(),listener,year,month, dayOfMonth);
        dialog.show();
    }

    DatePickerDialog.OnDateSetListener listener=new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
            etMaintenanceDate.setText(dayOfMonth+"/"+(month+1)+"/"+year);
        }
    };

}
