package com.example.housingsociety.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.housingsociety.R;
import com.example.housingsociety.model.Event;
import com.example.housingsociety.model.Member;

import java.util.ArrayList;
import java.util.HashMap;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    private ArrayList<HashMap<String, Event>> eventList;
    public interface EventClickListener {
        void onEventEdit(String key, Event event);
        void onEventDelete(String key, Event event);
    }

    private EventClickListener listener;
    public EventAdapter(ArrayList<HashMap<String, Event>> eventList, EventClickListener listener) {
        this.eventList=eventList;
        this.listener=listener;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.member_row_item,parent,false);
        EventViewHolder Holder= new EventViewHolder(view);
        return Holder;
    }

    @Override
    public void onBindViewHolder(@NonNull EventAdapter.EventViewHolder holder, int position) {
        HashMap<String, Event> hashMap=eventList.get(position);
        final String key=hashMap.keySet().iterator().next();
        final Event event=hashMap.get(key);

        holder.tvName.setText(event.getEventName());
        holder.tvHouseNo.setText("Date : "+event.getEventDate());

        holder.tvEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onEventEdit(key, event);
            }
        });

        holder.tvDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onEventDelete(key, event);
            }
        });
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }


    public class EventViewHolder extends RecyclerView.ViewHolder{
        TextView tvName, tvHouseNo;
        TextView tvEdit,tvDelete;
        public EventViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName=itemView.findViewById(R.id.tvName);
            tvHouseNo=itemView.findViewById(R.id.tvHouseNo);
        }
    }
}
