package com.example.housingsociety.model;

public class User {
    private String Username, Password, Role, First_name, last_name, Mobile, Email;

    public User(String Username,String Password,String Role,String First_name, String last_name,String Mobile,String Email){
        this.Username=Username;
        this.Password=Password;
        this.Role=Role;
        this.First_name=First_name;
        this.last_name=last_name;
        this.Mobile=Mobile;
        this.Email=Email;
    }

    public String getUsername() {

        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getRole() {
        return Role;
    }

    public void setRole(String role) {
        Role = role;
    }

    public String getFirst_name() {
        return First_name;
    }

    public void setFirst_name(String first_name) {
        First_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getMobile() {
        return Mobile;
    }

    public void setMobile(String mobile) {
        Mobile = mobile;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }
}
