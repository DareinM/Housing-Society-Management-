package com.example.housingsociety.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.housingsociety.R;
import com.example.housingsociety.model.Member;

import java.util.ArrayList;
import java.util.HashMap;

public class MemberAdapter extends RecyclerView.Adapter<MemberAdapter.MemberViewHolder> {

    private ArrayList<HashMap<String, Member>> memberList;

    public interface MemberClickListener {
        void onMemberEdit(String key, Member member);
        void onMemberDelete(String key, Member member);
    }

    private MemberClickListener listener;

    public MemberAdapter(ArrayList<HashMap<String, Member>> memberList, MemberClickListener listener) {
        this.memberList=memberList;
        this.listener=listener;
    }

    @NonNull
    @Override
    public MemberViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.member_row_item,parent,false);
        MemberViewHolder holder=new MemberViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MemberViewHolder holder, int position) {
        HashMap<String, Member> hashMap=memberList.get(position);
        final String key=hashMap.keySet().iterator().next();
        final Member member=hashMap.get(key);

        holder.tvName.setText(member.getFirstName()+" "+member.getLastName());
        holder.tvHouseNo.setText("House No : "+member.getHouseNo());

        holder.tvEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onMemberEdit(key, member);
            }
        });

        holder.tvDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onMemberDelete(key, member);
            }
        });
    }

    @Override
    public int getItemCount() {
        return memberList.size();
    }

    public class MemberViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvHouseNo;
        TextView tvEdit, tvDelete;
        public MemberViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName=itemView.findViewById(R.id.tvName);
            tvHouseNo=itemView.findViewById(R.id.tvHouseNo);
            tvEdit=itemView.findViewById(R.id.tvEdit);
            tvDelete=itemView.findViewById(R.id.tvDelete);
        }
    }
}
