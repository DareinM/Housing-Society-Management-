package com.example.housingsociety.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.housingsociety.R;
import com.example.housingsociety.model.Fund;

import java.util.ArrayList;
import java.util.HashMap;

public class FundAdapter extends RecyclerView.Adapter<FundAdapter.FundViewHolder> {
    private ArrayList<HashMap<String, Fund>> fundList;

    public interface FundClickListener {
        void onMemberEdit(String key, Fund fund);
        void onMemberDelete(String key, Fund fund);
    }
    private FundClickListener listener;

    public FundAdapter(ArrayList<HashMap<String, Fund>> fundList, FundClickListener listener) {
        this.fundList=fundList;
        this.listener=listener;
    }
    @NonNull
    @Override
    public FundViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.member_row_item,parent,false);
        FundViewHolder holder=new FundViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull FundViewHolder holder, int position) {
        HashMap<String, Fund> hashMap=fundList.get(position);
        final String key=hashMap.keySet().iterator().next();
        final Fund fund=hashMap.get(key);
    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class FundViewHolder extends RecyclerView.ViewHolder {
        public FundViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
