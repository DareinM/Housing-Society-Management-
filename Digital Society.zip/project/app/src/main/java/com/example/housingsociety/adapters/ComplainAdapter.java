package com.example.housingsociety.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.housingsociety.R;
import com.example.housingsociety.model.Complaint;


import java.util.ArrayList;
import java.util.HashMap;

public class ComplainAdapter extends RecyclerView.Adapter<ComplainAdapter.ComplainViewHolder> {

    private ArrayList<HashMap<String, Complaint>> complainlist;

    public ComplainAdapter(ArrayList<HashMap<String, Complaint>> complainlist) {
        this.complainlist=complainlist;
    }

    @NonNull
    @Override
    public ComplainViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.member_row_item,parent,false);
        ComplainViewHolder holder=new ComplainViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ComplainViewHolder holder, int position) {
        HashMap<String, Complaint> hashMap=complainlist.get(position);
        String key=hashMap.keySet().iterator().next();
        Complaint complain=hashMap.get(key);

        holder.tvName.setText(complain.getComplain());


    }

    @Override
    public int getItemCount() {
        return complainlist.size();
    }


    public class ComplainViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvHouseNo;
        public ComplainViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName=itemView.findViewById(R.id.tvName);
            tvHouseNo=itemView.findViewById(R.id.tvHouseNo);
        }
    }
}
